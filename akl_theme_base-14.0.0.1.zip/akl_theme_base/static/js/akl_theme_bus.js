odoo.define('akl_theme_base.bus', function (require) {
    "use strict";

    var Bus = require('web.Bus');
    var bus = new Bus();

    return bus;
});
