Added button to generate default stages and route on request type that has no
request stages.
