#### Version 1.16.2
Added generic_request_survey to request settings list.
