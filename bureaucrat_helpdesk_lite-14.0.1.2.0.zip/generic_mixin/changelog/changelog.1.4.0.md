Added mixin 'generic.mixin.transaction.utils'
