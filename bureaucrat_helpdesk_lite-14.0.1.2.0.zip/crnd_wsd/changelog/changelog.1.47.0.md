Automatically set channel to Website for requests created from website
