# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import payment_acquirer_onboarding_wizard
from . import sale_make_invoice_advance
from . import sale_product_configurator